
public class Greeting
{
	public String Greet()
	{
		return "Welcome to Java";
	}
}
